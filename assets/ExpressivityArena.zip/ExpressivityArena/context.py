import itertools
from typing import NamedTuple, List, Callable

from scipy.spatial import Voronoi, voronoi_plot_2d
from scipy.stats import entropy
from sklearn.decomposition import PCA
import numpy as np
import matplotlib.pyplot as plt



class SignalCategory(NamedTuple):
    """
    SignalCategory

    A list of grouped signals

    Signals in the same category should be mutual viable alternatives in a multiple-choice scenario

    For example, happiness, sadness, and anger could be a list of multiple choice options
    Meanwhile, happiness, Scottish, and Baroque-inspired are not a viable list of multiple choice options

    :param name: The name of the category
    :param signals: The list of grouped signals
    """
    name: str
    signals: List[str]

    def get_mean_pairwise_cosine_distance(self, encode: Callable[[str], List[float]]) -> float:
        embeddings = [encode(signal) for signal in self.signals]
        distances = [
            pow(emb1[0]-emb2[0], 2) + pow(emb1[1]-emb2[1], 2)
            for emb1, emb2 in itertools.product(embeddings, embeddings)
        ]
        return sum(distances) / len(distances)

    def get_median_voronoi_area(self, encode: Callable[[str], List[float]], side_count: int = 1000, graph_voronoi=False) -> float:
        embeddings = [encode(signal) for signal in self.signals]
        pca = PCA(n_components=2)
        reduced_embeddings = pca.fit_transform(embeddings)
        point_count = {tuple(embedding): 0 for embedding in reduced_embeddings}

        x_vals = [x for x, y in reduced_embeddings]
        y_vals = [y for x, y in reduced_embeddings]
        j = 0
        for x, y in itertools.product(np.linspace(min(x_vals), max(x_vals), side_count), np.linspace(min(y_vals), max(y_vals), side_count)):
            closest_embedding = min(reduced_embeddings, key=lambda em: pow(em[0]-x, 2) + pow(em[1]-y, 2))
            j+= 1
            point_count[tuple(closest_embedding)] += 1

        print(j, point_count)
        total_points = sum(point_count.values())
        probabilities = [count / total_points for count in point_count.values()]

        if graph_voronoi:
            plt.figure(figsize=(8, 6))
            plt.scatter(x_vals, y_vals, color='blue', alpha=0.7, label='Reduced Embeddings')


            # Plot Voronoi diagram.
            vor = Voronoi(reduced_embeddings)
            voronoi_plot_2d(vor, show_vertices=False, line_colors='orange', line_width=1.5, point_size=2)

            plt.xlabel('PCA Component 1')
            plt.ylabel('PCA Component 2')
            plt.title('Reduced Embeddings and Voronoi Diagram')
            plt.legend()
            plt.grid(True)
            plt.show()

        return np.median(probabilities)

class Context(NamedTuple):
    """
    Context

    A named domain describing a task for an ExpressivityArena test

    :param name: The name of an instance of the context, ie. "python program" or "poem"
    :param signal_categories: The list of categories containing possible signals
    """

    name: str
    signal_categories: List[SignalCategory]

    def signals(self):
        return [
            signal
            for category in self.signal_categories
            for signal in category.signals
        ]
