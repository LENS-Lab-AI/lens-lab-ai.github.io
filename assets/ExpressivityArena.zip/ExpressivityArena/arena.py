from typing import List, NamedTuple, Optional, IO

from context import SignalCategory
from grader import Grader
from llm import LLM


class ExpressivityPrompt(NamedTuple):
    """
    ExpressivityPrompt

    A prompt to produce a prompt in a particular context, encoding a particular expressive signal
    :param str instruction:         The type of response to generate, such as "poem," "speech," or "Python program."
    :param str expressivity_signal: The signal to encode into the response, such as "sad," "secretive," or
                                    "well-educated."
    """
    instruction: str
    expressivity_signal: str
    signal_category: Optional[SignalCategory]


class ExpressivityResult(NamedTuple):
    """
    ExpressivityResult

    The result of an ExpressivityArena experiment
    :param LLM LLM:                     The LLM used for the experiment
    :param ExpressivityPrompt prompt:   The prompt used for the experiment
    :param str result:                  The response the LLM gave for the above prompt
    :param bool grade:                  The grade of the response; true indicates that the response expressed the
                                        signal; False indicates the response didn't express the signal
    """
    LLM: LLM
    prompt: ExpressivityPrompt
    result: str
    grade: bool

def evaluate_prompts(
        llm: LLM,
        grader: Grader,
        prompts: List[ExpressivityPrompt],
        verbose: bool = False,
        n: int = 1
) -> List[ExpressivityResult]:
    """
    Returns a list of ExpressivityArena experiment results for a list of prompts

    :param llm:     The LLM to grade
    :param grader:  The grader to use
    :param prompts: The list of prompts to use
    :param verbose: Whether to print out messages tracking completion
    :param n:       The number of results to get per prompt
    :return:        The list of ExpressivityArena results
    """
    return [
        result
        for prompt in prompts
        for result in evaluate(llm, grader, prompt, verbose, n)
    ]


def evaluate_conversation(
        partners: List[LLM],
        grader: Grader,
        assigned_signals: List[str],
        category: SignalCategory,
        verbose: bool = False,
        n: int = 1
) -> List[List[ExpressivityResult]]:  # Maybe a new result class will be needed?
    """
    Evaluate a set of LLMs in a multi-participant conversation, where each one is given a signal to express
    :param assigned_signals:
    :param partners:
    :param grader:
    :param category:
    :param verbose:
    :param n:
    :return:
    """
    raise NotImplementedError


def evaluate(
        llm: LLM,
        grader: Grader,
        prompt: ExpressivityPrompt,
        verbose: bool = False,
        n: int = 1
) -> List[ExpressivityResult]:
    """
    Evaluates an ExpressivityArena prompt to produce an expressive result, then grades the expressivity of that response

    :param verbose:
    :param llm:      The LLM to grade
    :param grader:   The grader to use
    :param prompt:   The prompt to use, with the context and signal
    :param n:        The number of times to repeat the experiment
    :param verbose:  Whether to print out a message tracking completion
    :return:         The list of ExpressivityArena results
    """
    prompt_str = f"Write a {prompt.instruction} conveying {prompt.expressivity_signal} without explictly mentioning '\"{prompt.expressivity_signal}\"'. Do not also convey any of the following signals: {', '.join(prompt.signal_category.signals)}"

    if verbose:
        print(f"Evaluating {prompt.instruction} using {prompt.expressivity_signal}")

    def get_single_result():
        result = llm(prompt_str)
        while prompt.expressivity_signal.lower() in result.lower():
            result = llm(prompt_str)
        grade = grader(result, prompt.expressivity_signal, alternative_signals=prompt.signal_category.signals)

        return ExpressivityResult(
            llm,
            prompt,

            result,
            grade
        )

    results = [get_single_result() for _ in range(n)]
    if verbose:
        print(f"got {n} results.")
    return results


def evaluate_category(
        llm: LLM,
        grader: Grader,
        instruction: str,
        signal_category: SignalCategory,
        verbose: bool = False,
        n: int = 1
) -> List[ExpressivityResult]:
    """
    Evaluates all the expressive signals in a category

    :param llm:             The LLM to grade
    :param grader:          The grader to use
    :param instruction:     The instruction that determines the context
    :param signal_category: The category of signals to test
    :param n:               The number of tests per signal
    :param verbose:         Whether to print messages tracking completion
    :return:                The set of all results for each test
    """
    prompts = [
        ExpressivityPrompt(instruction, signal, signal_category)
        for signal in signal_category.signals
    ]

    return evaluate_prompts(llm, grader, prompts, verbose, n)
