# ExpressivityArena

ExpressivityArena is a project that evaluates the expressivity of Large Language Models. It utilizes LLM-powered grading to determine whether a response effectively expresses a given signal.

## Introduction

ExpressivityArena leverages a grader system, powered by an arbitrary LLM, to assess the expressivity of LLM-generated responses. It provides a framework for evaluating how well an LLM can convey specific signals within different contexts.

## Components

### LLM (Language Model)

The `LLM` class represents the functionality of a Language Model.
- `name`: The name of the LLM for identification purposes.
- `get_response`: A function representing the prompt -> response functionality of the LLM.

### ExpressivityPrompt

The `ExpressivityPrompt` class encapsulates a prompt to produce a response conveying a particular signal in a specific context.
- `instruction`: The type of response to generate, such as "poem," "speech," or "Python program."
- `expressivity_signal`: The signal to encode into the response, such as "sad," "secretive," or "well-educated."

### ExpressivityResult

The `ExpressivityResult` class represents the result of an ExpressivityArena experiment.
- `LLM`: The LLM used for the experiment.
- `prompt`: The prompt used for the experiment.
- `result`: The response the LLM gave for the prompt.
- `grade`: A boolean indicating whether the response effectively expressed the signal.

### Grader

The `Grader` class is a base class for grading whether responses express a given signal or not. Many different graders with different schemas are offered.

## Usage

### Evaluation

The `evaluate` function evaluates an ExpressivityArena prompt to produce an expressive result and then grades the expressivity of that response.
```
evaluate(llm: LLM, grader: Grader, prompt: ExpressivityPrompt) -> ExpressivityResult
```

### Batch Evaluation
The `batch_evaluate` function returns a list of ExpressivityArena experiment results for a list of prompts.

```
evaluate(llm: LLM, grader: Grader, prompts: List[ExpressivityPrompt]) -> List[ExpressivityResult]
```

## Example

```python
from arena import evaluate_category
from context import SignalCategory
from grader import MultipleChoiceGrader
from llm import LLM

# Initialize LLM and Grader
def gpt_response_function(prompt: str):
    # Fetch a response for the given prompt from the GPT API... 
    return response

llm = LLM(name="GPT", get_response=gpt_response_function)
grader = MultipleChoiceGrader(llm)

# Define signals
genres_category = SignalCategory("genres", [
        "horror", "romance", "thriller", "comedy", "drama"
])


# Evaluate prompts
results = evaluate_category(llm, grader, "short story", genres_category)

# Process results
for result in results:
    print(f"Prompt: {result.prompt}")
    print(f"Result: {result.result}")
    print(f"Grade: {'Expressive' if result.grade else 'Not Expressive'}")
    print()
```
