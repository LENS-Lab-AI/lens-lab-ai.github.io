import random
from typing import NamedTuple, List, Callable, Dict

from llm import LLM


class Grader:
    """
    Grader

    An LLM-powered system for grading whether responses express a given signal or not.
    """

    def __init__(self):
        raise NotImplementedError

    def grade(self, result: str, signal: str, alternative_signals: List[str]) -> bool:
        raise NotImplementedError

    def __call__(self, result: str, signal: str, alternative_signals: List[str] = None) -> bool:
        if alternative_signals is None:
            alternative_signals = []
        return self.grade(result, signal, alternative_signals)


class TrueFalseGrader(Grader):
    def __init__(self, llm: LLM):
        self.llm = llm

    def grade(self, result: str, signal: str, alternative_signals: List[str]) -> bool:
        prompt = f"Does the following prompt convey {signal}? Answer yes or no.\n{result}"

        grader_response = self.llm(prompt)

        return "yes" in grader_response.lower()


class MultipleChoiceGrader(Grader):
    """
    MultipleChoiceGrader

    A grader that allows the LLM to choose between a set of alternative signals
    """

    def __init__(self, llm: LLM, option_count: int = 4):
        self.llm = llm
        self.option_count = option_count

    def grade(self, result: str, signal: str, alternative_signals: List[str]) -> bool:
        selected_alternatives = random.sample(alternative_signals, self.option_count - 1)
        while signal in selected_alternatives:
            selected_alternatives = random.sample(alternative_signals, self.option_count - 1)

        ordered_options = selected_alternatives + [signal]
        random.shuffle(ordered_options)

        correct_answer = ordered_options.index(signal)

        option_text = "\n".join([f"{n}. {option}" for n, option in enumerate(ordered_options)])

        prompt = f"Which of the following is conveyed in the text?\n\n{option_text}\nAnswer ONLY with a number 0-{self.option_count - 1}. Here is the text: \n{result}"

        grader_response = self.llm(prompt)

        return str(correct_answer).lower() in grader_response.lower()


class ConfusionGrader(Grader):
    """
    ConfusionGrader

    A grader that builds a confusion matrix as it grades responses
    """

    def __init__(self, llm: LLM):
        self.llm = llm
        self.confusion_matrix = {}

    def grade(self, result: str, signal: str, alternative_signals: List[str]) -> bool:
        # alternative_signals += ["none of the others"]
        total_signals = list(set(alternative_signals).union({signal, "none of the others"}))

        signal_list_string = ", ".join(total_signals)
        prompt = f"Which of the following is conveyed in the text: {signal_list_string}?\nAnswer ONLY with an item from the list. Here is the text: \n{result}"

        grader_response = self.llm(prompt)

        answered_signals = [signal for signal in total_signals if signal.lower() in grader_response.lower()]

        answer = answered_signals[0] if len(answered_signals) > 0 else "None"

        if signal not in self.confusion_matrix:
            self.confusion_matrix[signal] = {}
        if answer not in self.confusion_matrix[signal]:
            self.confusion_matrix[signal][answer] = 0
        self.confusion_matrix[signal][answer] += 1

        return answer == signal

    def __repr__(self):
        return "Grader("+str(self.llm)+")"


def plurality(answers: Dict[str, int]) -> str:
    return max(answers.keys(), key=lambda key: answers[key])


class JuryGrader(Grader):
    """
    JuryGrader

    A grader that relies on a set of LLMs to make its judgement. Individual responses can be aggregated using an
    arbitrary consensus function to form the grader's final response
    """

    def __init__(self, llms: List[LLM], consensus_function: Callable[[Dict[str, int]], str] = plurality):
        self.llms = llms
        self.consensus_function = consensus_function

    def grade(self, result: str, signal: str, alternative_signals: List[str]) -> bool:
        answers = {}
        for llm in self.llms:
            total_signals = list(set(alternative_signals).union({signal}))

            signal_list_string = ", ".join(alternative_signals)
            prompt = f"Which of the following is conveyed in the text: {signal_list_string}?\nAnswer ONLY with an item from the list. Here is the text: \n{result}"

            grader_response = llm(prompt)

            answered_signals = [signal for signal in total_signals if signal.lower() in grader_response.lower()]

            answer = answered_signals[0] if len(answered_signals) > 0 else "None"

            if answer not in answers:
                answers[answer] = 0

            answers[answer] += 1
        answer = self.consensus_function(answers)
        return answer == signal
