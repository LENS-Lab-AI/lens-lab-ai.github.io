from typing import Callable, NamedTuple


class LLM(NamedTuple):
    """
    LLM

    Represents an LLM's functionality
    :param str name:                            The name of the LLM for identification purposes
    :param Callable[[str], str] get_response:   A function representing the prompt -> response functionality of the LLM.
    """
    name: str
    get_response: Callable[[str], str]

    def __call__(self, prompt: str) -> str:
        return self.get_response(prompt)
